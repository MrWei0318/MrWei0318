%% 清楚、输入数据

data1=readcell("CUMCM2023Problems\C题\附件1 - 副本.xlsx");
data2=readcell("CUMCM2023Problems\C题\附加2修改.xlsx");
data3=readcell("CUMCM2023Problems\C题\附件3 - 副本.xlsx");
data11=cell2mat(data1(2:end,1));
data21=cell2mat(data2(2:end,3:4));
data22=cell2mat(data2(2:end,1));
data23=cell2mat(data2(2:end,3:5));
data31=cell2mat(data3(2:end,1:3));
idx_not = find(strcmp(data2(:,7), '否' ));
idx_yes = find(strcmp(data2(:,7),'是'));
data21_not=data23(idx_not-1,:);
data21_yes=data23(idx_yes-1,:);
data22_not=data22(idx_not-1,:);
data22_yes=data22(idx_yes-1,:);
data_not=[data22_not data21_not];
data_yes=[data22_yes data21_yes];
%% 折扣率

for i=1:length(data_yes)
    a=find(data_not(:,1)==data_yes(i,1));% 判断日期相同
    a1=data_yes(i,2:4);
    a_1=find(data_not(a,2)==a1(1,1));
    if isempty(a_1)==1
        buckling(i,1)=0;
    else
        a2=a1(1,3)/data_not(a_1(1),4);
        buckling(i,1)=a2;
    end
end
buckl=[data_yes buckling];
m=1;
b_1=zeros(251,1200);
for j=1:length(data_yes)
    a=find(data11(:,1)==buckl(j,2));
    b_1(a,m)=b_1(a,m)+buckl(j,5);
    flig_time=isempty(find(data22_yes(j,1)==data22(:,1)));
    if j<length(data_yes)&&data_yes(j+1)==data_yes(j)&&flig_time==0
        continue
    else
        m=m+1;
    end
end
B_1=[]
for i=1:251
    B_1(i,1)=sum(b_1(i,:))
end
for i=1:length(data11)
    a=find(data11(i,1)==data_yes(:,2))
    nn(i,1)=numel(a);
end
bucklen=[]
bucklen(1)=sum(B_1(1:100))/sum(nn(1:100)+50)
bucklen(2)=sum(B_1(101:105))/sum(nn(101:105)+200)
bucklen(3)=sum(B_1(106:124))/sum(nn(106:124)+220)
bucklen(4)=sum(B_1(125:134))/sum(nn(125:134))
bucklen(5)=sum(B_1(135:179))/sum(nn(135:179))
bucklen(6)=sum(B_1(180:end))/sum(nn(180:end))+200)

%% 打折出售的蔬菜品类及量
m=1;
b_2=zeros(251,1200);
for j=1:length(data21_yes)
    a=find(data11(:,1)==data21_yes(j,1));
    b_2(a,m)=b_2(a,m)+data21_yes(j,2);
    flig_time=isempty(find(data22_yes(j,1)==data22(:,1)));
    if j<length(data22_yes)&&data22_yes(j+1)==data22_yes(j)&&flig_time==0
        continue
    else
        m=m+1;
    end
end

%% 未打折出售的蔬菜品类及量
m=1;
b_2_1=zeros(251,1200);
for j=1:length(data21_not)
    a=find(data11(:,1)==data21_not(j,1));
    b_2_1(a,m)=b_2_1(a,m)+data21_not(j,2);
    if j<length(data22_not)&&data22_not(j+1)==data22_not(j)
        continue
    else
        m=m+1;
    end
end
%% 销售订单的利润 
for i=1:length(data22_not)
    p_price=[];
    tim=find(data31(:,1)==data22_not(i,1));
    p_price=data31(tim,2:3);
    cclass=find(p_price(:,1)==data21_not(i,1));
    u_price(i,1)=data21_not(i,3)-p_price(cclass,2);
    u_price_m(i,1)=data21_not(i,3)/p_price(cclass,2)-1;
end
%% 日均利润率
m=1;
u_m=zeros(251,1200);  
n=zeros(251,1200)
for j=1:length(u_price_m)
    a=find(data11(:,1)==data21_not(j,1))
    u_m(a,m)=u_m(a,m)+u_price_m(j,1);
    n(a,m)=n(a,m)+1;
    if j<length(data22_not)&&data22_not(j+1)==data22_not(j)
        continue
    else
        m=m+1;
    end
end

[p,q]=size(u_m);
for i=1:p
    for j=1:q
        u_m_t(i,j)=u_m(i,j)/n(i,j);
    end
end
u_m_t(find(isnan(u_m_t)==1)) = 0
%% 品类利润率
class_m=zeros(6,1085);
for j=1:length(u_m_t)-15
    for m=1:width(u_m_t')
        if m<101
            class_m(1,j)=class_m(1,j)+u_m_t(m,j)
            continue
        else
            if m<106
                class_m(2,j)=class_m(2,j)+u_m_t(m,j);
                continue
            else
                if m<125
                    class_m(3,j)=class_m(3,j)+u_m_t(m,j);
                    continue
                else
                    if m<135
                        class_m(4,j)=class_m(4,j)+u_m_t(m,j);
                        continue
                    else
                        if m<180
                            class_m(5,j)=class_m(5,j)+u_m_t(m,j);
                            continue
                        else
                            class_m(6,j)=class_m(6,j)+u_m_t(m,j);
                        end
                    end
                end
            end
        end
    end
    N1(1,j)=nnz(u_m_t(1:100,j));
    N2(1,j)=nnz(u_m_t(101:105,j));
    N3(1,j)=nnz(u_m_t(106:124,j));
    N4(1,j)=nnz(u_m_t(125:134,j));
    N5(1,j)=nnz(u_m_t(135:179,j));
    N6(1,j)=nnz(u_m_t(180:end,j));
end
class_am=zeros(6,1085)
for j=1:1085
    class_am(1,j)=class_m(1,j)/N1(1,j);
    class_am(2,j)=class_m(2,j)/N2(1,j);
    class_am(3,j)=class_m(3,j)/N3(1,j);
    class_am(4,j)=class_m(4,j)/N4(1,j);
    class_am(5,j)=class_m(5,j)/N5(1,j);
    class_am(6,j)=class_m(6,j)/N6(1,j);
end
data_class=[]
for i=1:6
    data_class(:,2*i-1:2*i)=[class(i,:)' class_am(i,:)'];
end
xlswrite("品类回归.xlsx",data_class)

%% 日销售利润
m=1;
u_1=zeros(251,1200);
for j=1:length(u_price)
    a=find(data11(:,1)==data21_not(j,1))
    u_1(a,m)=u_1(a,m)+u_price(j,1)*data21_not(j,2);
    if j<length(data22_not)&&data22_not(j+1)==data22_not(j)
        continue
    else
        m=m+1;
    end
end
