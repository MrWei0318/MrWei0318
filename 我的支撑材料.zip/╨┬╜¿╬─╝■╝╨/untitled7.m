%% 数据读取及数据选择
X=xlsread("品类回归.xlsx");
x1=X(end-30:end,1);
y1=X(end-30:end,2);
x2=X(end-30:end,3);
y2=X(end-30:end,4);
x3=X(end-30:end,5);
y3=X(end-30:end,6);
x4=X(end-30:end,7);
y4=X(end-30:end,8);
x5=X(end-30:end,9);
y5=X(end-30:end,10);
x6=X(end-30:end,11);
y6=X(end-30:end,12);
rstool(x1,y1,z1)
%% 花叶类拟合函数
plot(x1);
[P,S]=polyfit(y1,x1,3)
xi=y1;
yi=polyval(P,xi);
hold on
plot(yi)
x_1=[x1(4,:) x1(5,:) x1(11,:) x1(12,:) x1(18,:) x1(19,:) x1(25,:) x1(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%% 花菜类拟合函数
plot(x2);
[P,S]=polyfit(y2,x2,1)
xi=y2;
yi=polyval(P,xi);
hold on
plot(yi)
x_1=[x2(4,:) x2(5,:) x2(11,:) x2(12,:) x2(18,:) x2(19,:) x2(25,:) x2(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%% 水产植物类拟合函数
plot(x3);
[P,S]=polyfit(y3,x3,1)
xi=y3;
yi=polyval(P,xi);
hold on
plot(yi)
x_1=[x3(4,:) x3(5,:) x3(11,:) x3(12,:) x3(18,:) x3(19,:) x3(25,:) x3(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%% 辣椒类拟合函数
plot(x4);
[P,S]=polyfit(y4,x4,1)
xi=y4;
yi=polyval(P,xi);
hold on
plot(yi)
x_1=[x4(4,:) x4(5,:) x4(11,:) x4(12,:) x4(18,:) x4(19,:) x4(25,:) x4(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%% 茄类拟合函数
plot(x5);
[P,S]=polyfit(y5,x5,1)
xi=y5;
yi=polyval(P,xi);
hold on
plot(yi)
legend('原始','拟合')
xlabel('时间')
ylabel('销量')
title('拟合函数')
x_1=[x5(4,:) x5(5,:) x5(11,:) x5(12,:) x5(18,:) x5(19,:) x5(25,:) x5(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%% 食用菌拟合函数
plot(x6);
[P,S]=polyfit(y6,x6,3)
xi=y6;
yi=polyval(P,xi);
hold on
plot(yi)
x_1=[x6(4,:) x6(5,:) x6(11,:) x6(12,:) x6(18,:) x6(19,:) x6(25,:) x6(26,:)]
x_2=[xi(4,:) xi(5,:) xi(11,:) xi(12,:) xi(18,:) xi(19,:) xi(25,:) xi(26,:)]
x_x=x_1-x_2
plot(x_x)
y_y=1:8;
%%
x1=X(end-6:end,1);
y1=X(end-6:end,2);
z1=[1,1,0,0,0,0,0]
x0=[0,0,0];
fun=@(p)p(1)+p(2)*y1+p(3)*z1-x1;
x=lsqnonlin(fun,x0)

