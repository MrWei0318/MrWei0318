%% 清理、读取数据
clc
clear
data1=readcell("CUMCM2023Problems\C题\附件1 - 副本.xlsx");
data2=readcell("CUMCM2023Problems\C题\附加2修改.xlsx");
data11=cell2mat(data1(2:end,1));
data21=cell2mat(data2(2:end,3:4));
data22=cell2mat(data2(2:end,1));
data23=cell2mat(data2(2:end,3:5));
%% 去除异常值
data21(579908,:)=[];
data21(214033,:)=[];
data22(579908,:)=[];
data22(214033,:)=[];
data23(579908,:)=[];
data23(214033,:)=[];
%% 不同种类的日销量
m=1;
b=zeros(251,1085);
for j=1:length(data22)
    a=find(data11(:,1)==data21(j,1));
    b(a,m)=b(a,m)+data21(j,2);
    if j<length(data22)&&data22(j+1)==data22(j)
        continue
    else
        m=m+1;
    end
end
%% 不同种类的总销量
for i=1:length(data11)
    sell_kind(i,1)=sum(b(i,:));
    
end

%% 日销总量
for i=1:length(b)
    sell_day(i,1)=sum(b(:,i))
end
plot(sell_day)
xlabel('时间')
ylabel('销量')
title('每天的销量')
%% 不同种类价格的相关数据
for j=1:length(data11)
    a=find(data21(:,1)==data11(j,1));
    box=data23(a,3);
    flag=isempty(box);
    if flag==1
        flag1(j,1)=nan;
    else
        statistics(j,1)=max(box);
        statistics(j,2)=min(box);
        statistics(j,3)=range(box);
        statistics(j,4)=numel(a);
        statistics(j,5)=mean(box);
        statistics(j,6)=std(box);
        statistics(j,7)=median(box);
        if numel(a)>4
            flag1(j,1) = lillietest(box)
        else
            flag1(j,1)=nan;
        end
    end
end
%xlswrite("统计值_价格.xlsx",statistics);
%% 不同种类销量的相关数据
for j=1:length(data11)
    a=find(data21(:,1)==data11(j,1));
    sell=data23(a,2);
    flag=isempty(sell);
    if flag==1
        flag1(j,1)=nan;
    else
        statistics_sell(j,1)=max(sell);
        statistics_sell(j,2)=min(sell);
        statistics_sell(j,3)=range(sell);
        statistics_sell(j,4)=numel(a);
        statistics_sell(j,5)=mean(sell);
        statistics_sell(j,6)=std(sell);
        statistics_sell(j,7)=median(sell);
        if numel(a)>4
            flag1(j,1) = lillietest(sell)
        else
            flag1(j,1)=nan;
        end
    end
end
%xlswrite("统计值_销量.xlsx",statistics_sell);
%% 品类的销量热度
class_sell=zeros(6,1);
for m=1:width(b')
    if m<101
        class_sell(1,1)=class_sell(1,1)+statistics_sell(m,4)
     continue
    else
        if m<106
            class_sell(2,1)=class_sell(2,1)+statistics_sell(m,4);
            continue
        else
            if m<125
                class_sell(3,1)=class_sell(3,1)+statistics_sell(m,4);
                continue
            else
                if m<135
                    class_sell(4,1)=class_sell(4,1)+statistics_sell(m,4);
                    continue
                else
                    if m<180
                        class_sell(5,1)=class_sell(5,1)+statistics_sell(m,4);  
                        continue
                    else
                        class_sell(6,1)=class_sell(6,1)+statistics_sell(m,4);
                    end
                end
            end
        end
    end
end
pie(class_sell)
title('不同种类销售次数占比')
legend('花叶类','花菜类','水生根茎类','茄类','辣椒类','食用菌')
%% 单品的销量热度
for i=1:length(statistics_sell)
    s_s(i,:)=[statistics_sell(i,:),i];
end
ss=sortrows(s_s(:,4:8),1,'descend');
label={'芜湖青椒(1)','西兰花','西峡香菇(1)','云南生菜','净藕(1)','紫茄子(2)','泡泡椒(精品)','云南油麦菜','螺丝椒','上海青','竹叶菜','金针菇(盒)','紫白菜(1)','大白菜','黄白菜(2)','云南生菜(份)','菠菜','奶白菜','小米椒','红薯尖'}
bar(ss(1:20,3))
xlabel("单品")
ylabel('标准差')
title('单品标准差直方图')
set(gca,'XTick',1:20,'XTickLabel',label)
%% 销售热度前5的销量变化
c_b=b(ss(1:5,5),:);
plot(c_b','LineWidth',1);
xlabel('时间')
ylabel('销量')
title('销售热度前5的日销量变化')
legend('芜湖青椒(1)','西兰花','西峡香菇(1)','云南生菜','净藕(1)')
%%
c_b1=b(ss(1,5),:);
plot(c_b1','LineWidth',1);

legend('芜湖青椒(1)')
%% 品类的日销
class=zeros(6,1085);
for j=1:length(b)
    for m=1:width(b')
        if m<101
            class(1,j)=class(1,j)+b(m,j)
            continue
        else
            if m<106
                class(2,j)=class(2,j)+b(m,j);
                continue
            else
                if m<125
                    class(3,j)=class(3,j)+b(m,j);
                    continue
                else
                    if m<135
                        class(4,j)=class(4,j)+b(m,j);
                        continue
                    else
                        if m<180
                            class(5,j)=class(5,j)+b(m,j);
                            continue
                        else
                            class(6,j)=class(6,j)+b(m,j);
                        end
                    end
                end
            end
        end
    end
end

xlswrite("品种日销.xlsx",class_totil);
plot(class(:,1:1085)','LineWidth',1);
xlabel('时间')
ylabel('销量')
title('不同种类的日销量')
legend('花叶类','花菜类','水生根茎类','茄类','辣椒类','食用菌')
xlswrite('品类日销.xlsx',class(:,1:1085)')
%% 不同种类的月销售量
for i=1:36
    for j=1:width(b')
        if i<36
            mouth(i,j)=sum(b(j,i*30-29:i*30));
        else
            mouth(i,j)=sum(b(j,i*30-29:end));
        end
    end
end
%rrr=corr(mouth);
%heatmap(rrr)
%[col,row]=find(abs(rrr)>=0.95 & abs(rrr)<1);
%aa=[col,row];
%xlswrite("relation .xlsx",aa);
%% 销量热度前5的月销售量变化
c_b_mouth=mouth(:,ss(1:5,5));
plot(c_b_mouth,'LineWidth',1);
xlabel('月份变化')
ylabel('销量')
title('销售热度前5的月销量变化')
legend('芜湖青椒(1)','西兰花','西峡香菇(1)','云南生菜','净藕(1)')

%% 季节
season_class=[];
for i=1:11
    for j=1:6
        season_class(i,j)=sum(mouth_class(3*i-1:3*i+2,j))
    end
end
season_class=[(mouth_class(1,:)+mouth_class(2,:))*3/2;season_class]
season_class=[season_class;mouth_class(end,:)*3];
xlswrite("季节销量.xlsx",season_class)

plot(season_class,'LineWidth',2)
xlabel('季节')
ylabel('销量')
title('季节销量')
legend('花叶类','花菜类','水生根茎类','茄类','辣椒类','食用菌')
%% 种类的季节销售量
season=[];
for i=1:11
    for j=1:width(b')
            season(i,j)=sum(mouth(i*3-2:i*3,j));

    end
end
season=[(mouth(1,:)+mouth(2,:))*3/2;season];
season=[season;mouth(end,:)*3];

c_b_season=season(:,ss(1:5,5));
plot(c_b_season,'LineWidth',1);
xlabel('季节变化')
ylabel('销量')
title('销售热度前5的季节销量变化')
legend('芜湖青椒(1)','西兰花','西峡香菇(1)','云南生菜','净藕(1)')
%% 不同品类的月销售量
for i=1:36
    for j=1:6
        if i<36
            mouth_class(i,j)=sum(class(j,i*30-29:i*30));
        else
            mouth_class(i,j)=sum(class(j,i*30-29:end));
        end
    end
end
%xlswrite("mouth_class.xlsx",mouth_class);
%% 绘图1
plot(mouth_class,'LineWidth',2);
title('不同种类月销售图')
xlabel('月份')
ylabel('销售量')
legend('花叶类','花菜类','水生根茎类','茄类','辣椒类','食用菌')
set(gca,'XTickLabel',{'20年6月';'20年11月';'21年4月';'21年9月';'22年2月';'22年7月';'22年12月';'23年6月';'23年11月'})
%% 绘图2
x=[1:12];
y=mouth_class(1:12,:);
plot(x,y(:,:),'LineWidth',2);
title('不同种类月销售图')
xlabel('月份')
ylabel('销售量/千克')
legend('花叶类','花菜类','水生根茎类','茄类','辣椒类','食用菌')
set(gca,'XTickLabel',{'6月';'8月';'10月';'12月';'2月';'4月';'6月'})
%% 数据输出
xlswrite("class.xlsx",class');
xlswrite("shuju.xlsx",b);
xlswrite("shuju_B.xlsx",b');
