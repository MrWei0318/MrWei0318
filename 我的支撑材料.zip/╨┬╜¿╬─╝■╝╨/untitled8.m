clc
clear
data1=readcell("CUMCM2023Problems\C题\附件1 - 副本.xlsx");
data2=readcell("CUMCM2023Problems\C题\附加2修改.xlsx");
data3=readcell("CUMCM2023Problems\C题\附件3 - 副本.xlsx");
data4=readcell("CUMCM2023Problems\C题\附件4 - 副本.xlsx");
data1=cell2mat(data1(2:end,1));
data2_1=cell2mat(data2(2:end,1));
data2_2=cell2mat(data2(2:end,3:5));
data2=[data2_1 data2_2];
data3=cell2mat(data3(2:end,:));
data4=table2cell(S1);
data4_1=cell2mat(data4(:,1));
data4_2=cell2mat(data4(:,3));
data4=[data4_1 data4_2];
%% 第三问数据预处理
a=find(data2(:,1)>45100);
C=data2(a,:);
for i=1:length(C)
    a=find(data1(:,1)==C(i,2));
    C_1(a,1)=1;
end
b=find(data3(:,1)==45107);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,2)=data3(i,3);
end
b=find(data3(:,1)==45106);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,3)=data3(i,3);
end
b=find(data3(:,1)==45105);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,4)=data3(i,3);
end
b=find(data3(:,1)==45104);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,5)=data3(i,3);
end
b=find(data3(:,1)==45103);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,6)=data3(i,3);
end
b=find(data3(:,1)==45102);
c=data3(b,2:3);
for i=1:length(c)
    a=find(data1(:,1)==c(i,1));
    C_1(a,7)=data3(i,3);
end
for i=1:length(data1)
    a=find(data1(i,1)==data4(:,1))
    beta(a,1)=data4(a,2);
end



