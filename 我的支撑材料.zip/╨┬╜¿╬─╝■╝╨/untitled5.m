data1=readcell("CUMCM2023Problems\C题\附件1 - 副本.xlsx");
data2=readcell("CUMCM2023Problems\C题\附加2修改.xlsx");
data3=readcell("CUMCM2023Problems\C题\附件3 - 副本.xlsx");
data4=table2cell(S2);
data41=cell2mat(data4(:,3));
sell_class(1)=sum(sell_kind(1:100))
sell_class(2)=sum(sell_kind(101:105))
sell_class(3)=sum(sell_kind(106:124))
sell_class(4)=sum(sell_kind(125:134))
sell_class(5)=sum(sell_kind(135:179))
sell_class(6)=sum(sell_kind(180:end))
%% 损失率
loss(1)=sum(sell_kind(1:100,1).*data41(1:100,1)/sell_class(1));
loss(2)=sum(sell_kind(101:105,1).*data41(101:105,1)/sell_class(2));
loss(3)=sum(sell_kind(106:124,1).*data41(106:124,1)/sell_class(3));
loss(4)=sum(sell_kind(125:134,1).*data41(125:134,1)/sell_class(4));
loss(5)=sum(sell_kind(135:179,1).*data41(135:179,1)/sell_class(5));
loss(6)=sum(sell_kind(180:end,1).*data41(180:end,1)/sell_class(6));

